import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './pages/Home';  // Correct path to HomePage component
import About from './pages/About';  // Correct path to AboutPage component
import Nav from './components/Nav';
import Service from './pages/Service';
import ServiceDetail from './pages/ServiceDetail';


const App = () => {
  return (
    <Router>
      <Nav />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/service" element={<Service />} />
        <Route path="/service-detail" element={<ServiceDetail />} />
      </Routes>
    </Router>
  );
};

export default App;
