

import React from 'react';
import { Link } from 'react-router-dom';
import Nav from '../components/Nav.jsx';
import Hero from '../components/Hero.jsx';
import groupImg from '../assets/Group 44.png';
import rectThreeImg from '../assets/Rectangle 3.png';
import uiUxImg from '../assets/UIUX.png';
import imageUrl from '../assets/Rectangle 39.png';
import Thatslot from '../components/Thatslot.jsx';
import Footer from '../components/Footer.jsx';


const Service = () => {
   
    return (
        <>
            <Nav />
            <Hero
                heading="OUR SERVICES"
                imageUrl={imageUrl}
                paraText='Delivery cutting edge solution tailored to your business needs'
                buttontext="Learn More"
            />

            <div className="flex flex-wrap justify-around bg-white p-4 shadow-lg font-[Dubai]">
                <h1 className="text-2xl sm:text-xl md:text-3xl font-bold text-black pl-2">Github</h1>
                <h1 className="text-2xl sm:text-xl md:text-3xl font-bold text-black pl-2">Github</h1>
                <h1 className="text-2xl sm:text-xl md:text-3xl font-bold text-black pl-2">Github</h1>
                <h1 className="text-2xl sm:text-xl md:text-3xl font-bold text-black pl-2">Github</h1>
                <h1 className="text-2xl sm:text-xl md:text-3xl font-bold text-black pl-2">Github</h1>
            </div>

            <div className="flex justify-center my-8">
                <h1 className="text-3xl font-bold text-center border-b-4 border-violet-500 inline-block pb-2">
                    Our Offerings
                </h1>
            </div>

            <section className="flex justify-around bg-white p-4 shadow-lg font-[Dubai] cursor-pointer">
                <div className="relative group">
                    <img src={rectThreeImg} className="object-cover w-full h-full" alt="Rectangle 3" />
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className=" text-center p-4">
                            <h2 className="text-1xl text-violet-500 font-bold mb-2">Business Planning</h2>
                        </div>
                    </div>
                </div>
                <div className="relative group">
                    <img src={uiUxImg} className="object-cover w-full h-full" alt="UI/UX" />
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className=" text-center p-4">
                            <h2 className="text-1xl text-violet-500 font-bold">UI/UX Designing</h2>
                        </div>
                    </div>
                </div>
                <div className="relative group">
                    <img src={groupImg} className="object-cover w-full h-full" alt="Group 44" />
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className=" text-center p-4">
                            <h2 className="text-1xl text-violet-500 font-bold mb-2">Web Development</h2>
                        </div>
                    </div>
                </div>
            </section>
            <section className="flex justify-around bg-white p-4 shadow-lg font-[Dubai] cursor-pointer">
                <div className="relative group">
                    <img src={rectThreeImg} className="object-cover w-full h-full" alt="Rectangle 3" />
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className=" text-center p-4">
                            <h2 className="text-1xl text-violet-500 font-bold mb-2">Business Planning</h2>
                        </div>
                    </div>
                </div>
                <div className="relative group">
                    <img src={uiUxImg} className="object-cover w-full h-full" alt="UI/UX" />
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className=" text-center p-4">
                            <h2 className="text-1xl text-violet-500 font-bold">UI/UX Designing</h2>
                        </div>
                    </div>
                </div>
                <div className="relative group">
                    <img src={groupImg} className="object-cover w-full h-full" alt="Group 44" />
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className=" text-center p-4">
                            <h2 className="text-1xl text-violet-500 font-bold mb-2">Web Development</h2>
                        </div>
                    </div>
                </div>
            </section>
            <section className="flex justify-around bg-white p-4 shadow-lg font-[Dubai] cursor-pointer">
                <div className="relative group">
                    <img src={rectThreeImg} className="object-cover w-full h-full" alt="Rectangle 3" />
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className=" text-center p-4">
                            <h2 className="text-1xl text-violet-500 font-bold mb-2">Business Planning</h2>
                        </div>
                    </div>
                </div>
                <div className="relative group">
                    <img src={uiUxImg} className="object-cover w-full h-full" alt="UI/UX" />
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className=" text-center p-4">
                            <h2 className="text-1xl text-violet-500 font-bold">UI/UX Designing</h2>
                        </div>
                    </div>
                </div>
                <div className="relative group">
                    <img src={groupImg} className="object-cover w-full h-full" alt="Group 44" />
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className=" text-center p-4">
                            <h2 className="text-1xl text-violet-500 font-bold mb-2">Web Development</h2>
                        </div>
                    </div>
                </div>
            </section>

            <div className='flex justify-center items-center'>
                <Link to="/service-detail" className="mt-12 flex justify-center items-center bg-violet-600 text-white font-bold text-lg py-3 px-6 rounded-lg hover:bg-violet-700 transition-colors duration-300 font-[Dubai]">
                    See Our Work
                </Link>
            </div>

            


            <section className='bg-black py-10 my-12'>
                <Thatslot
                    heading2='Thats Alot'
                    heading1="Give your company a faster, more agile way to work with freelancers and contractors. Find contract and pay your external workforce in one click, with 100% compliance."
                    box="BOOK A DEMO"

                />
                <div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-center text-white font-[Dubai]'>
                    <div className='flex flex-col items-center'>
                        <ion-icon name="settings-outline" style={{ fontSize: '3rem', color: 'grey' }}></ion-icon>
                        <span className='mt-2 text-2xl font-bold text-gray-500'>12+ Services</span>
                    </div>
                    <div className='flex flex-col items-center'>
                        <ion-icon name="flash-outline" style={{ fontSize: '3rem', color: 'grey' }}></ion-icon>
                        <span className='mt-2 text-2xl text-gray-500 font-bold'>120+ Projects</span>
                    </div>
                    <div className='flex flex-col items-center'>
                        <ion-icon name="cash-outline" style={{ fontSize: '3rem', color: 'grey' }}></ion-icon>
                        <span className='mt-2 text-2xl text-gray-500 font-bold'>30k+ Revenue</span>
                    </div>
                    <div className='flex flex-col items-center'>
                        <ion-icon name="people-outline" style={{ fontSize: '3rem', color: 'grey' }}></ion-icon>
                        <span className='mt-2 text-2xl text-gray-500 font-bold'>100k+ Happy Clients</span>
                    </div>
                </div>
            </section>

        



            <Footer />
        </>
    );
}

export default Service;
