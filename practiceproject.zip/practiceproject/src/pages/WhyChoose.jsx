import React from 'react';

const WhyChoose = ({ headingshort, textt }) => {
    return (
        <div className='bg-black p-6 sm:p-12 flex justify-center items-center shadow-lg font-[Dubai]'>
            <div className='bg-white rounded shadow-lg text-black text-center py-4 max-w-xs sm:max-w-md md:max-w-lg lg:max-w-xl'>
                <h4 className='font-bold text-md sm:text-lg md:text-xl lg:text-2xl'>{headingshort}</h4>
                <p className='text-center py-2 sm:py-4 px-4 text-gray-500'>
                    {textt}
                </p>
            </div>

            
        </div>
    );
}

export default WhyChoose;
