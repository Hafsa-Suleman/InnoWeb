import React from 'react';
import Hero from '../components/Hero.jsx';
import imageUrl from '../assets/Rectangle 39.png';
import Nav from '../components/Nav.jsx';
import Section from '../components/Section.jsx';
import heroImg from '../assets/img1.png';
import imageSrc from '../assets/Rectangle 6.png';
import rectSeven from '../assets/Rectangle 7.png';
import imgTwo from '../assets/img2.png';
import Thatslot from '../components/Thatslot.jsx';
import '../App.css';
import serviceImg1 from '../assets/Rectangle 12.png';
import serviceImg2 from '../assets/Rectangle 13.png';
import serviceImg3 from '../assets/Rectangle 14.png';
import serviceImg4 from '../assets/Rectangle 15.png';
import Footer from '../components/Footer.jsx';
import Testimonal from '../components/Testimonal';
import userIcon from '../assets/user-icon.png';

const Home = () => {
    const reviews = [
        {
            name: 'John Doe',
            review: 'Working with InnoWeb was a game-changer for our business. Their expertise in web development and digital solutions helped us launch a seamless, user-friendly platform that our customers love...',
            image: userIcon,
        },
        {
            name: 'Jane Smith',
            review: 'Working with InnoWeb was a game-changer for our business. Their expertise in web development and digital solutions helped us launch a seamless, user-friendly platform that our customers love...',
            image: userIcon,
        },
        {
            name: 'Robert Johnson',
            review: 'I highly recommend InnoWeb for anyone looking to build a professional and effective online presence...',
            image: userIcon,
        },
    ];

    return (
        <>
            <Nav />
            <Hero
                heading="Empowering Your Business with IT Innovation"
                imageUrl={imageUrl}
                paraText="We specialize in delivering cutting-edge IT services tailored to meet the unique needs of businesses across industries. Our expert team is dedicated to providing comprehensive solutions that drive efficiency, enhance security, and foster innovation."
                buttontext="Learn More"
            />

            <div className="flex flex-wrap justify-around bg-white p-4 shadow-lg font-[Dubai]">
                <h1 className="text-2xl sm:text-xl md:text-3xl font-bold text-black pl-2">Github</h1>
                <h1 className="text-2xl sm:text-xl md:text-3xl font-bold text-black pl-2">Github</h1>
                <h1 className="text-2xl sm:text-xl md:text-3xl font-bold text-black pl-2">Github</h1>
                <h1 className="text-2xl sm:text-xl md:text-3xl font-bold text-black pl-2">Github</h1>
               
            </div>

            <Thatslot
                heading2="Thats Alot"
                heading1="Give your company a faster, more agile way to work with freelancers and contractors. Find contract and pay your external workforce in one click, with 100% compliance."
                box="BOOK A DEMO"
            />

            <section className="flex flex-col items-center mt-8">
                <img src={heroImg} alt="heroimage" className="w-full max-w-2xl object-cover" />
                <p className="mt-4 text-lg sm:text-xl md:text-2xl w-11/12 text-center font-[Dubai]">
                    Give your company a faster, more agile way to work with freelancers and contractors. <br />
                    Find, contract, and pay your external workforce in one click, with 100% compliance.
                </p>
            </section>

            <div className="flex justify-center my-8">
                <h1 className="text-3xl font-bold text-center border-b-4 border-violet-500 inline-block pb-2">
                    Everything You Need To Get Ahead
                </h1>
            </div>

            <Section
                imageSrc={imageSrc}
                mainheading="The Fastest Hiring and Payments"
                content="We specialize in delivering cutting-edge IT services tailored to meet the unique needs of businesses across industries. Our expert team is dedicated to providing comprehensive solutions that drive efficiency, enhance security, and foster innovation."
                imageFirst={true}
            />

            <Section
                imageSrc={rectSeven}
                mainheading="The Fastest Hiring and Payments"
                content="We specialize in delivering cutting-edge IT services tailored to meet the unique needs of businesses across industries. Our expert team is dedicated to providing comprehensive solutions that drive efficiency, enhance security, and foster innovation."
                imageFirst={false}
            />

            <Section
                imageSrc={imgTwo}
                mainheading="The Fastest Hiring and Payments"
                content="We specialize in delivering cutting-edge IT services tailored to meet the unique needs of businesses across industries. Our expert team is dedicated to providing comprehensive solutions that drive efficiency, enhance security, and foster innovation."
                imageFirst={true}
            />

            <Thatslot
                heading2="Thats Alot"
                heading1="Give your company a faster, more agile way to work with freelancers and contractors. Find contract and pay your external workforce in one click, with 100% compliance."
                box="BOOK A DEMO"
            />

            <section className="bg-black py-10 my-12">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                    <img src={serviceImg1} alt="service 1" className="w-full h-48 object-cover shadow-lg" />
                    <img src={serviceImg2} alt="service 2" className="w-full h-48 object-cover shadow-lg" />
                    <img src={serviceImg3} alt="service 3" className="w-full h-48 object-cover shadow-lg" />
                    <img src={serviceImg4} alt="service 4" className="w-full h-48 object-cover shadow-lg" />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-center text-white font-[Dubai]">
                    <div className="flex flex-col items-center">
                        <ion-icon name="settings-outline" style={{ fontSize: '3rem', color: 'grey' }}></ion-icon>
                        <span className="mt-2 text-xl md:text-2xl font-bold text-gray-500">12+ Services</span>
                    </div>
                    <div className="flex flex-col items-center">
                        <ion-icon name="flash-outline" style={{ fontSize: '3rem', color: 'grey' }}></ion-icon>
                        <span className="mt-2 text-xl md:text-2xl text-gray-500 font-bold">120+ Projects</span>
                    </div>
                    <div className="flex flex-col items-center">
                        <ion-icon name="cash-outline" style={{ fontSize: '3rem', color: 'grey' }}></ion-icon>
                        <span className="mt-2 text-xl md:text-2xl text-gray-500 font-bold">30k+ Revenue</span>
                    </div>
                    <div className="flex flex-col items-center">
                        <ion-icon name="people-outline" style={{ fontSize: '3rem', color: 'grey' }}></ion-icon>
                        <span className="mt-2 text-xl md:text-2xl text-gray-500 font-bold">100k+ Happy Clients</span>
                    </div>
                </div>
            </section>

            <div className="flex justify-center my-8">
                <h1 className="text-3xl font-bold text-center border-b-4 font-[Dubai] border-violet-500 inline-block pb-2">
                    Testimonials
                </h1>
            </div>

            <div className="px-4 sm:px-8">
                <Testimonal reviews={reviews} />
            </div>

            <Thatslot
                heading2="Thats Alot"
                heading1="Give your company a faster, more agile way to work with freelancers and contractors. Find contract and pay your external workforce in one click, with 100% compliance."
                box="BOOK A DEMO"
            />

            <Footer />
        </>
    );
};

export default Home;
