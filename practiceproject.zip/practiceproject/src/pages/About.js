

import React from 'react';

import Hero from '../components/Hero.jsx';
import imageUrl from '../assets/Rectangle 39.png';
import Nav from '../components/Nav.jsx';
import Section from '../components/Section.jsx';
import imgOnee from '../assets/img2.png';
import imgTwin from '../assets/img2.png';
import Cards from '../components/Cards.jsx';
import rectImgg from '../assets/Rectangle 55.png';
import WhyChoose from './WhyChoose.jsx';
import '../App.css';
import userIcon from '../assets/user-icon.png';
import Testimonal from '../components/Testimonal';
import Footer from '../components/Footer.jsx';

const About = () => {


    const reviews = [
        {
            name: 'John Doe',
            review: 'Working with InnoWeb was a game-changer for our business. Their expertise in web development and digital solutions helped us launch a seamless, user-friendly platform that our customers love...',
            image: userIcon,
        },
        {
            name: 'Jane Smith',
            review: 'Working with InnoWeb was a game-changer for our business. Their expertise in web development and digital solutions helped us launch a seamless, user-friendly platform that our customers love...',
            image: userIcon,
        },
        {
            name: 'Robert Johnson',
            review: 'I highly recommend InnoWeb for anyone looking to build a professional and effective online presence...',
            image: userIcon,
        },
    ];
    return (


        <>
            <Nav />

            <Hero
                heading="OUR STORY"
                imageUrl={imageUrl}
                paraText="Lorem ipsum dolor sit amet consectetur. Leo id bibendum aliquam eget"
                buttontext="Learn More"
            />

            <div className="flex flex-wrap justify-around bg-white p-4 shadow-lg font-[Dubai]">
                <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-black pl-2">Github</h1>
                <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-black pl-2">Github</h1>
                <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-black pl-2">Github</h1>
                <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-black pl-2">Github</h1>
                <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-black pl-2">Github</h1>
            </div>

            <div className="flex justify-center my-20">
                <h1 className="text-3xl font-bold text-center border-b-4 border-violet-500 inline-block pb-2">
                    Everything You Need To Get Ahead
                </h1>
            </div>

            <div className='flex flex-col sm:flex-row justify-center p-10 m-10 items-center bg-violet-500 
            shadow-lg text-center font-[Dubai]'>
                <p className='text-lg'>
                    Background or why we started the company... Lorem ipsum dolor sit amet consectetur.
                    Pulvinar scelerisque purus suscipit cursus vestibulum nibh proin neque. Sed neque
                    cursus congue ultrices enim donec in. Diam pretium odio tortor amet amet molestie
                    enim aliquam massa vitae. Lorem ipsum dolor sit amet consectetur. Pulvinar scelerisque

                    purus suscipit cursus vestibulum nibh proin neque. Sed neque cursus congue ultrices
                    enim donec in. Diam pretium odio tortor amet amet molestie enim aliquam massa vitae.
                </p>
            </div>

            <div className="flex justify-center my-20">
                <h1 className="text-3xl font-bold text-center border-b-4 border-violet-500 inline-block pb-2">
                    Our Team
                </h1>
            </div>

            <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
                <Cards
                    rectImgg={rectImgg}
                    headingsolo='Mujtaba Nasir'
                    para='DIRECTOR'
                />
                <Cards
                    rectImgg={rectImgg}
                    headingsolo='Kashaf Noor'
                    para='Board Of Director'
                />
                <Cards
                    rectImgg={rectImgg}
                    headingsolo='Sameen Noor'
                    para='Project Manager'
                />
            </div>

            <Section
                imageSrc={imgOnee}
                mainheading='OUR MISSION'
                content='We specialize in delivering cutting-edge IT services tailored to meet the unique needs of businesses across industries. Our expert team is dedicated to providing comprehensive solutions that drive efficiency, enhance security, and foster innovation.'
                imageFirst={true} // Image on the right
            />

            <Section
                imageSrc={imgTwin}
                mainheading='OUR GOALS'
                content='We specialize in delivering cutting-edge IT services tailored to meet the unique needs of businesses across industries. Our expert team is dedicated to providing comprehensive solutions that drive efficiency, enhance security, and foster innovation.'
                imageFirst={false} // Image on the left
            />

            <div className="bg-black py-10">
                <div className="flex justify-center pb-10">
                    <h1 className="text-2xl sm:text-3xl md:text-5xl text-white text-center border-b-4 border-violet-500 pb-2 font-[Dubai]">
                        Why You Choose Us
                    </h1>
                </div>
                <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
                    <WhyChoose
                        headingshort='Customer-Centric Approach'
                        textt='Lorem ipsum dolor sit amet consectetur. Tortor
sapien commodo nisi volutpat. Lobortis
sed.Lorem ipsum dolor sit amet consectetur.
Tortor sapien commodo nisi volutpat. Lobortis
sed.'
                    />
                    <WhyChoose
                        headingshort='Innovation'
                        textt='Lorem ipsum dolor sit amet consectetur. Tortor
sapien commodo nisi volutpat. Lobortis
sed.Lorem ipsum dolor sit amet consectetur.
Tortor sapien commodo nisi volutpat. Lobortis
sed.'
                    />
                    <WhyChoose
                        headingshort='Reliability'
                        textt='Lorem ipsum dolor sit amet consectetur. Tortor
sapien commodo nisi volutpat. Lobortis
sed.Lorem ipsum dolor sit amet consectetur.
Tortor sapien commodo nisi volutpat. Lobortis
sed.'
                    />
                </div>

              
            </div>

            <div className="flex justify-center my-8">
                <h1 className="text-3xl font-bold text-center border-b-4 font-[Dubai] border-violet-500 inline-block pb-2">
                    Testimonials
                </h1>
            </div>
<div className="px-4 sm:px-8">
                <Testimonal reviews={reviews} />
            </div>
           
            <Footer />

        </>
    );
}

export default About;
