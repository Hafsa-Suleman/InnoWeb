import React, { useState } from 'react';
import Hero from '../components/Hero.jsx';
import imageUrl from '../assets/Rectangle 39.png';
import Nav from '../components/Nav.jsx';
import Section from '../components/Section.jsx';
import heroImg from '../assets/img1.png';
import rectEarth from '../assets/Rectangle 84.png';
import WhyChoose from './WhyChoose.jsx';
import Footer from '../components/Footer.jsx';
import Testimonal from '../components/Testimonal';
import userIcon from '../assets/user-icon.png'

const ServiceDetail = () => {
  const reviews = [
    {
        name: 'John Doe',
        review: 'Working with InnoWeb was a game-changer for our business. Their expertise in web development and digital solutions helped us launch a seamless, user-friendly platform that our customers love...',
        image: userIcon,
    },
    {
        name: 'Jane Smith',
        review: 'Working with InnoWeb was a game-changer for our business. Their expertise in web development and digital solutions helped us launch a seamless, user-friendly platform that our customers love...',
        image: userIcon,
    },
    {
        name: 'Robert Johnson',
        review: 'I highly recommend InnoWeb for anyone looking to build a professional and effective online presence...',
        image: userIcon,
    },
];
  const [visibleSections, setVisibleSections] = useState({});

  const handleIconClick = (index) => {
    setVisibleSections(prevState => ({
      ...prevState,
      [index]: !prevState[index],
    }));
  };

  const sections = [
    {
      heading: 'Lorem ipsum dolor sit amet consectetur. Tortor sapien commodo nisi volutpat. Lobortis sed.',
      content: 'Artificial Intelligence (AI) refers to the simulation of human intelligence in machines that are programmed to think, learn, and adapt like humans. AI encompasses a broad range of technologies, from simple algorithms to sophisticated neural networks.'
    },
    {
      heading: 'Lorem ipsum dolor sit amet consectetur. Tortor sapien commodo nisi volutpat. Lobortis sed.',
      content: 'Artificial Intelligence (AI) refers to the simulation of human intelligence in machines that are programmed to think, learn, and adapt like humans. AI encompasses a broad range of technologies, from simple algorithms to sophisticated neural networks.'
    },
    {
      heading: 'Lorem ipsum dolor sit amet consectetur. Tortor sapien commodo nisi volutpat. Lobortis sed.',
      content: 'Artificial Intelligence (AI) refers to the simulation of human intelligence in machines that are programmed to think, learn, and adapt like humans. AI encompasses a broad range of technologies, from simple algorithms to sophisticated neural networks.'
    },
    {
      heading: 'Lorem ipsum dolor sit amet consectetur. Tortor sapien commodo nisi volutpat. Lobortis sed.',
      content: 'Artificial Intelligence (AI) refers to the simulation of human intelligence in machines that are programmed to think, learn, and adapt like humans. AI encompasses a broad range of technologies, from simple algorithms to sophisticated neural networks.'
    },
    {
      heading: 'Lorem ipsum dolor sit amet consectetur. Tortor sapien commodo nisi volutpat. Lobortis sed.',
      content: 'Artificial Intelligence (AI) refers to the simulation of human intelligence in machines that are programmed to think, learn, and adapt like humans. AI encompasses a broad range of technologies, from simple algorithms to sophisticated neural networks.'
    },
    
  ];

  return (
    <>
      <Nav />
      <Hero
        heading="Empowering Your Business with IT Innovation"
        imageUrl={imageUrl}
        paraText="Delivering cutting-edge digital solutions tailored to your business needs"
        buttontext="Learn More"
      />

      <div className="flex flex-wrap justify-around bg-white p-4 shadow-lg font-[Dubai] space-y-4 sm:space-y-0">
      
        <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-black pl-2">Github</h1>
        <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-black pl-2">Github</h1>
        <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-black pl-2">Github</h1>
        <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-black pl-2">Github</h1>
      </div>

      <div className="flex justify-center my-8">
        <h1 className="text-2xl sm:text-3xl font-bold text-center border-b-4 border-violet-500 pb-2">
          Service Description
        </h1>
      </div>

      <div className='flex flex-col sm:flex-row justify-center p-6 md:p-10 m-4 md:m-10 items-center bg-violet-500 shadow-lg text-center font-[Dubai]'>
        <p className='text-base sm:text-lg'>
          Background or why we started the company... Lorem ipsum dolor sit amet consectetur.
          Pulvinar scelerisque purus suscipit cursus vestibulum nibh proin neque. Sed neque
          cursus congue ultrices enim donec in. Diam pretium odio tortor amet amet molestie
          enim aliquam massa vitae. Lorem ipsum dolor sit amet consectetur. Pulvinar scelerisque
          purus suscipit cursus vestibulum nibh proin neque. Sed neque cursus congue ultrices
          enim donec in. Diam pretium odio tortor amet amet molestie enim aliquam massa vitae.
        </p>
      </div>

      <div className='flex flex-col sm:flex-row justify-around items-start font-[Dubai] p-4'>
  <div className='space-y-4'>
    <h3 className="text-xl sm:text-2xl border-b-4 py-2 text-center border-500">
      Front-End Development
    </h3>
    <h3 className="text-xl sm:text-2xl border-b-4 py-2 text-center border-500">
      Back-End Development
    </h3>
    <h3 className="text-xl sm:text-2xl border-b-4 py-2 text-center border-500">
      Content Management System (CMS) Integration
    </h3>
    <h3 className="text-xl sm:text-2xl border-b-4 py-4 text-center border-500">
      Word-Press Development
    </h3>
    <h3 className="text-xl sm:text-2xl border-b-4 py-2 text-center border-500">
      Shopify Development
    </h3>
  </div>

  <div className='flex-shrink-0 w-full sm:w-1/2 lg:w-1/3 flex items-center justify-center'>
    <img src={rectEarth} alt="Earth" className="max-w-full max-h-[400px] object-contain" />
  </div>
</div>



      <div className="flex justify-center my-8">
        <h1 className="text-2xl sm:text-3xl font-bold text-center border-b-4 border-violet-500 pb-2">
          Advantages
        </h1>
      </div>

      <div className='py-3 mb-7 px-4 sm:px-10 text-base sm:text-lg font-[Dubai]'>
        <ul className="list-disc list-inside">
          <li className='py-2'>Lorem ipsum dolor sit amet consectetur. Nulla commodo fermentum felis enim eleifend tellus leo hac.</li>
          <li className='py-2'>Tristique morbi suspendisse sit vestibulum euismod sit in aliquam. Ipsum pellentesque aliquam elementum sed.</li>
          <li className='py-2'>Dictum velit eros amet morbi augue egestas.</li>
          <li className='py-2'>Congue facilisis senectus amet commodo aliquam vitae mi amet duis.</li>
          <li className='py-2'>Arcu malesuada quam arcu consectetur aliquam. Habitasse eu sem vitae vel id diam.</li>
          <li className='py-2'>Euismod in eget risus etiam a nullam. Potenti netus ipsum sit amet in diam sit vel non.</li>
        </ul>
      </div>


      <div className="bg-black py-8">
        <div className="flex justify-center pb-8">
          <h1 className="text-2xl sm:text-3xl md:text-4xl text-white text-center border-b-4 border-violet-500 pb-2 font-[Dubai]">
            Our Process
          </h1>
        </div>
        <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
          <WhyChoose
            headingshort='Discovery'
            textt='Lorem ipsum dolor sit amet consectetur. Tortor sapien commodo nisi volutpat. Lobortis sed.'
          />
          <WhyChoose
            headingshort='Planning'
            textt='Lorem ipsum dolor sit amet consectetur. Tortor sapien commodo nisi volutpat. Lobortis sed.'
          />
          <WhyChoose
            headingshort='Execution'
            textt='Lorem ipsum dolor sit amet consectetur. Tortor sapien commodo nisi volutpat. Lobortis sed.'
          />
        </div>
      </div>
      <div className="flex justify-center my-8">
                <h1 className="text-3xl font-bold text-center border-b-4 font-[Dubai] border-violet-500 inline-block pb-2">
                    Testimonials
                </h1>
            </div>
<div className="px-4 sm:px-8">
                <Testimonal reviews={reviews} />
            </div>

      <div className="flex justify-center my-8">
        <h1 className="text-3xl sm:text-4xl font-bold text-center border-b-4 border-violet-500 pb-2">
          FaQs
        </h1>
      </div>

      <div className='flex flex-col items-center px-4 sm:px-10 text-base sm:text-lg border-b-4 border-500'>
        {sections.map((section, index) => (
          <div key={index} className='mb-6 w-full max-w-3xl'>
            <div className='flex items-center mb-4'>
              <h2 className='pr-4 text-base sm:text-lg border-b-4 border-500'>
                {section.heading}
              </h2>

              <span 
                className='text-3xl sm:text-4xl text-violet-500 cursor-pointer'
                onClick={() => handleIconClick(index)}
              >
                <ion-icon name="add-circle-outline"></ion-icon>
              </span>
            </div>

            {visibleSections[index] && (
              <p className='text-base sm:text-lg'>
                {section.content}
              </p>
            )}
          </div>
        ))}
      </div>

      <Footer />
    </>
  );
}

export default ServiceDetail;
