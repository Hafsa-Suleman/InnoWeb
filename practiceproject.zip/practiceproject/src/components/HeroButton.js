import React from 'react';

const HeroButton = ({ variant, children }) => {
  let buttonStyle = '';

  if (variant === 'transparent') {
    buttonStyle = 'bg-transparent border-2 border-white text-white';
  } else if (variant === 'solid') {
    buttonStyle = 'bg-violet-600 text-white';
  }

  return (
    <button
      className={`font-bold text-xs md:text-sm lg:text-base py-2 px-3 md:py-2 md:px-4 lg:py-3 lg:px-6 mr-2 md:mr-3 hover:bg-violet-400 duration-500 ${buttonStyle}`}
    >
      {children}
    </button>
  );
};

export default HeroButton;
