import React from 'react';

const Thatslot = ({ heading1, heading2, box }) => {
  return (
    <div className='bg-gray-500 p-4 sm:p-5 m-4 sm:m-6 shadow-xl flex flex-col h-full'>
      <h1 className='font-bold text-lg sm:text-xl text-white'>{heading2}</h1>
      <p className='text-base sm:text-lg text-white max-w-full sm:max-w-5xl flex-grow mt-2'>
        {heading1}
      </p>
      <div className='text-right mt-4'>
        <button className='bg-black font-bold text-white text-xs sm:text-sm py-2 sm:py-3 px-4 sm:px-6'>
          {box}
        </button>
      </div>
    </div>
  );
}

export default Thatslot;
