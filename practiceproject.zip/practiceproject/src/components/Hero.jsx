import React from 'react';
import HeroButton from './HeroButton';

const Hero = ({ heading, imageUrl, paraText }) => {
  return (
    <div className="relative w-full h-screen pt-16 sm:pt-20">
      <div 
        className="absolute top-0 left-0 w-full h-full bg-black"
        style={{
          clipPath: 'polygon(0% 0%, 300% 0%, 50% 100%, 0% 100%)',
        }}
      />

      <div
        className="absolute top-0 right-0 w-full h-full"
        style={{
          clipPath: 'polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)',
        }}
      >
        <img
          className="absolute right-0 h-full w-full object-cover"
          src={imageUrl}
          alt=""
        />
      </div>

      <div className="absolute top-0 left-0 w-full h-full flex flex-row justify-left items-center text-white z-20 px-4 sm:px-8">
        <div className="text-center space-y-6 pt-16 sm:pt-24">
          <h1 className="font-bold text-3xl sm:text-4xl md:text-5xl drop-shadow-md sm:drop-shadow-xl max-w-[90%] md:max-w-[800px] mx-auto">
            {heading}
          </h1>
          <p className="text-sm sm:text-base md:text-lg max-w-[90%] md:max-w-[800px] mx-auto py-4 sm:py-6">
            {paraText}
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-x-4 sm:space-y-0 mt-8">
            <HeroButton variant="solid">
              BOOK A DEMO
            </HeroButton>
            <HeroButton variant="transparent">
              REQUEST A QUOTE
            </HeroButton>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
