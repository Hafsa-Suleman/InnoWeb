
import React from 'react';

const Section = ({ imageSrc, content, mainheading, imageFirst = true }) => {
    return (
        <section className={`flex flex-col md:flex-row ${imageFirst ? '' : 'md:flex-row-reverse'} gap-8 py-8 px-4`}>
           
            <div className="flex-1 flex justify-center items-center">
                <img src={imageSrc} alt="Section Image" className="w-full max-w-xl object-contain" />
            </div>
           
            <div className="flex-1 flex flex-col justify-center pl-8 font-[Dubai]">
                <h1 className="text-4xl font-bold mb-6">{mainheading}</h1>
                <p className="text-2xl mb-6 font-[Dubai]">{content}</p>
                <div className="text-xl mt-4">
                    <h2 className="text-2xl font-semibold mb-4 font-[Dubai]">Managed IT Services:</h2>
                    <ul className="list-disc pl-5 mb-6 font-[Dubai] text-3lg">
                        <li>Manages IT Services:</li>
                        <li>Cloud Solution</li>
                        <li>Cybersecurity:</li>
                        <li>IT Consulting</li>
                    </ul>
                    <p className="border-b-2 border-violet-400 inline-block cursor-pointer pb-1">Pay your external workforce in one click.</p>
                </div>
            </div>
        </section>




    );
}

export default Section;

