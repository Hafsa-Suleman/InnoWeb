import React from 'react';
const Footer = () => {
  return (
    <footer className='bg-black text-violet-500 py-8'>
      <div className='container mx-auto px-4'>
        <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8'>
          {/* Company Info */}
          <div>
            <h3 className='text-lg font-semibold  text-white mb-4 '>InnoWeb</h3>
            <p className='mb-4'>
              Lorem ipsum dolor sit amet consectetur. Laoreet cras egestas.
              Lorem ipsum dolor sit amet consectetur. Laoreet cras egestas.
              Lorem ipsum dolor sit amet consectetur. Laoreet cras egestas.
              Lorem ipsum dolor sit amet consectetur. Laoreet cras egestas.
              Lorem ipsum dolor sit amet consectetur. Laoreet cras egestas.
            </p>
            
          </div>
          
          {/* Services */}
          <div>
            <h3 className='text-lg font-semibold   text-white mb-4'>Services</h3>
            <ul className='list-disc pl-5'>
              <li><a href="#" className='hover:text-gray-400'>Web Development</a></li>
              <li><a href="#" className='hover:text-gray-400'>UI/UX Design</a></li>
              <li><a href="#" className='hover:text-gray-400'>Graphic Design</a></li>
              <li><a href="#" className='hover:text-gray-400'>Business Planning</a></li>
            </ul>
          </div>
          
          {/* Useful Links */}
          <div>
            <h3 className='text-lg font-semibold  text-white  mb-4'>Useful Links</h3>
            <ul className='list-disc pl-5'>
              <li><a href="#" className='hover:text-gray-400'>Lorem</a></li>
              <li><a href="#" className='hover:text-gray-400'>Contact Us</a></li>
              <li><a href="#" className='hover:text-gray-400'>Lorem ipsum</a></li>
              <li><a href="#" className='hover:text-gray-400'>Testimonials</a></li>
            </ul>
          </div>
          
          {/* Follow Us */}
          <div>
            <h3 className='text-lg font-semibold   text-white mb-4'>Follow Us</h3>
            <ul className='list-none flex space-x-4'>
              <li>
                <a href="#" className='text-violet-500 hover:text-gray-400'>
                <ion-icon name="logo-facebook" style={{ fontSize: '2rem' }}></ion-icon>
                </a>
              </li>
              <li>
                <a href="#" className='text-violet-500 hover:text-gray-400'>
                <ion-icon name="logo-youtube" style={{ fontSize: '2rem'}}></ion-icon>
                </a>
              </li>
              <li>
                <a href="#" className='text-violet-500 hover:text-gray-400'>
                <ion-icon name="logo-instagram" style={{ fontSize: '2rem' }}></ion-icon>
                </a>
              </li>
              <li>
                <a href="#" className='text-violet-500 hover:text-gray-400'>
                <ion-icon name="logo-whatsapp" style={{ fontSize: '2rem'}}></ion-icon>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className='bg-gray-800 py-4 text-center'>
        <p className='text-gray-400 text-sm'>© 2024 InnoWeb. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
