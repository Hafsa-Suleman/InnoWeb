import React from 'react';

const Cards = ({ headingsolo, para, rectImgg }) => {
  return (
    <div className="flex justify-center items-center space-x-4 py-4">
      <div className="bg-black inline-block m-3 max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg">
        <img src={rectImgg} alt="Card Image" className="w-full h-auto object-cover" />
        <div className="content p-4">
          <h1 className="cursor-pointer py-4 text-white text-center text-xl sm:text-2xl md:text-3xl font-bold font-[Dubai]">
            {headingsolo}
          </h1>
          <p className="font-[Dubai] cursor-pointer py-2 text-white text-center font-bold text-sm sm:text-base md:text-lg">
            {para}
          </p>
          <div className="flex justify-center items-center space-x-4 py-4 text-xl sm:text-2xl md:text-3xl cursor-pointer">
            <span>
              <ion-icon style={{ color: 'blue' }} name="logo-facebook"></ion-icon>
            </span>
            <span>
              <ion-icon style={{ color: 'blue' }} name="logo-youtube"></ion-icon>
            </span>
            <span>
              <ion-icon style={{ color: 'blue' }} name="logo-instagram"></ion-icon>
            </span>
            <span>
              <ion-icon style={{ color: 'blue' }} name="logo-whatsapp"></ion-icon>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cards;
