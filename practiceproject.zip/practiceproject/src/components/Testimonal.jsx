import React, { useState, useEffect } from 'react';

const Testimonial = ({ reviews }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [currentDateTime, setCurrentDateTime] = useState('');

  useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      const formattedDateTime = now.toLocaleString('en-US', {
        dateStyle: 'medium',
        timeStyle: 'short',
      });
      setCurrentDateTime(formattedDateTime);
    };

    updateDateTime();
    const intervalId = setInterval(updateDateTime, 60000); // Update every minute

    return () => clearInterval(intervalId); // Clean up on unmount
  }, []);

  const handlePrev = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? reviews.length - 1 : prevIndex - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex === reviews.length - 1 ? 0 : prevIndex + 1));
  };

  return (
    <div className="bg-white shadow-xl p-4 sm:p-6 md:p-10">
      <div className="relative flex flex-col bg-violet-400 items-center p-4 sm:p-6 md:p-8 shadow-lg rounded-lg max-w-full sm:max-w-2xl mx-auto">
        <div className="flex flex-col sm:flex-row items-center w-full">
          <button 
            className="text-2xl text-gray-600 hover:text-gray-800 mb-4 sm:mb-0 sm:mr-4" 
            onClick={handlePrev}
          >
            &larr;
          </button>
          <div className="flex-1 px-2 sm:px-4">
            <div className="flex items-center mb-4">
              <img
                src={reviews[currentIndex].image}
                alt={`${reviews[currentIndex].name}'s picture`}
                className="w-10 h-10 sm:w-12 sm:h-12 rounded-full object-cover mr-2 sm:mr-4"
              />
              <h2 className="text-lg sm:text-xl font-bold">{reviews[currentIndex].name}</h2>
            </div>
            <p className="text-sm sm:text-md">{reviews[currentIndex].review}</p>
          </div>
          <button 
            className="text-2xl text-gray-600 hover:text-gray-800 mt-4 sm:mt-0 sm:ml-4" 
            onClick={handleNext}
          >
            &rarr;
          </button>
        </div>
        <div className="absolute top-2 right-2 text-xs sm:text-sm text-gray-600">
          {currentDateTime}
        </div>
      </div>
    </div>
  );
};

export default Testimonial;
